# Isolated elementary Work rehearsal

This is an engineering test, not a novel result. Read research/workspaces/cycle-fixture/problem.md and the preserved RUN.
