# fixture-A

Engineering fixture; no novel mathematics.

For every integer n, n + 1 >= n.

Since 1 >= 0, translation of the integer order gives n + 1 >= n. All variables range over the integers.
