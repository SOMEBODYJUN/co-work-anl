# Allowed initial warning

A finite check alone does not prove a universally quantified integer inequality.
