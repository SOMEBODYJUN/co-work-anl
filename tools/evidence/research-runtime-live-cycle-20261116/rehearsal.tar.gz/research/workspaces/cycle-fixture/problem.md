# Engineering fixture, not a research claim

For every integer n, prove n + 4 >= n in the usual order.
Intermediate facts are n + 1 >= n and n + 2 >= n.
