# Model

The domain is the integers with their usual order. Addition preserves the order and the domain is closed under addition.
