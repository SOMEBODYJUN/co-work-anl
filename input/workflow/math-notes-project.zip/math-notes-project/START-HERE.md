# 用于新 Codex 项目的数学手记复核包

本包提供项目内技能、完整总提示词、子代理合同、PDF 切图工具、结构审计工具和自检。它帮助执行和追踪流程，不是一个保证零错误的 OCR 模型。

## 使用

1. 解压到新 Codex 项目根目录，保留 `.agents/skills/`（它是以点开头的目录）。项目内已经放入上游 `handwritten-math-notes-to-latex` 完整快照和本项目 `math-notes-evidence-audit`。
2. 将每课原 PDF 放到 `input/pdf/`，对应旧 Markdown 放到 `input/previous-notes/`，教师额外材料可放到 `input/teacher/`。保留原文件名，由代理核实对应关系，不只按文件顺序猜。
3. 把 `prompts/coordinator-prompt.md` 全文作为新任务发送。它明确授权实际启动子代理，采用三份一批、跨轮新审阅者、逐页放大复核、修改后重置计数。发生中断时使用 `prompts/resume-prompt.md`。
4. 缺依赖时，在项目环境安装 `.agents/skills/math-notes-evidence-audit/scripts/requirements.txt` 中的依赖，再运行同目录 `selftest.py`。工具的真实命令和账本格式见 `references/tools.md`；不要凭提示词猜 API。
5. 先确认模型能实际打开图像、执行 Python、写文件并启动子代理。选择 Pro 或把 ZIP 上传到普通 ChatGPT Project，不能代替这些能力检查，也不代表项目技能已自动安装。无子代理时明确保留未达到的独立复核门槛。

## 交付结构

每份笔记保留两种正文：`source-transcript.md` 按原稿页序完整转写；`study-notes.md` 按复习顺序编排。后者保留完整目录、题目与完整解答、原知识点及各自证明，采用黑色原文、蓝色就地补充/订正、红色原留白。疑点、来源映射、逐页覆盖、数学恢复和各轮审阅放在独立记录中，不把正式笔记改成审计报告。

默认批次为第1—3份、第4—6份、第7—9份、第10—11份。正常情况下每个批次完成所有步骤再进入下一批，实际可用并发较低时缩小批次。真正无法排除的材料/工具阻塞，必须保留未完成状态与交接，再继续其他可做工作，不能算作通过。每份笔记的后续审阅者须是未参与过该笔记的新代理；支持时用 `fork_turns="none"`。该参数不是所有产品都有的通用命令。

## 已验证与未验证

- 已实际下载并阅读上游固定快照，保留其许可。上游脚本边界测试结果与评估在 `validation/` 和 `docs/upstream-review.md`。
- 本项目脚本自检与独立测试结果在 `validation/`。测试通过指的是这些明确列出的合成案例，不代表对用户全部笔记的内容认证。
- 已在当前可读的《实分析11》副本上跑过全页/切图预处理，结果见 `validation/preprocess-smoke.json`。没有在这一步宣称全页内容识读或独立复核完成。
- 本包不包含用户的全部十一份原稿及旧稿；它们需要在新项目中由用户提供。也不包含用户文字中提到但未实际附上的 `math-notes-zero-omission/skill.zip`；本包是本轮实际编写和测试的独立补强。
- 未安装可选 OCR 模型和下载权重，未测得整批手稿识别准确率。候选与边界见 `docs/optional-ocr.md`。

任何完整性脚本都不能证明审阅者真正认真看过图片，也不能证明来源单元清单已经穷尽全部原稿。必须执行新的独立图像初读和稿件对照。连续三轮无新发现是用户选择的流程条件，不是零错保证。

## 参考

- [Codex 本地项目技能发现](https://learn.chatgpt.com/docs/build-skills)
- [子代理能力、可用性与配置](https://learn.chatgpt.com/docs/agent-configuration/subagents)
- [项目和聊天的区别](https://learn.chatgpt.com/docs/projects)
- [视觉模型已知限制](https://developers.openai.com/api/docs/guides/images-vision)
- [本包采用的上游项目](https://github.com/JiangZhexin/handwritten-math-notes-to-latex)
