# 数学与公式解析核验

本轮范围：作者初读、旧稿对照、数学补充及公式解析。未执行最终独立复核。

## 已运行的 Python 核验

精确输入和原始输出保存在 `math-validation.json`：使用分子 -8 至 8、分母 1 至 4 的有理数去重排序，数值采用 Fraction；同一组值也作阈值。另检查零值、空定义域、正负无穷及旧稿公式的逆向恢复。

| 检查 | 次数 |
| --- | --- |
| decomposition_A | 45 |
| absolute_value_B | 45 |
| old_positive_part_formula_finite | 45 |
| inverse_recovery_finite | 45 |
| positive_superlevel | 2025 |
| negative_superlevel | 2025 |
| empty_domain_level_sets | 90 |

上述程序检查的失败项为 0。有限枚举只作辅助，不等于一般定理证明。

## 完整证明与条件

- A 与 B 按原稿各自的非负/负值分支完整保留；没有以“同理”省掉原有步骤。
- 旧稿半和式在有限实数上按两种符号完整验证；由原稿 A+B 相加再除以二进行逆向核对。
- 可测性补证明对任意实阈值分段列出严格上水平集，含阈值零及空定义域；先备判据在调用前写出。
- 原稿 A/B 与水平集公式可处理扩展值；旧稿半和式在负无穷处含负无穷加正无穷，因此蓝色限定逐点有限条件。这是适用范围说明，不是字迹疑点。

## 外部数学核验

实际检索并打开了 [J. K. Hunter，UC Davis 测度论讲义第3章](https://www.math.ucdavis.edu/~hunter/measure_theory/measure_notes_ch3.pdf)，核验命题3.5的水平集判据及命题3.7的 max/min 可测结论。该资料不用于原文识读，不更改课堂负部定义。

## 公式解析与显示限制

- `render-preview.mjs` 使用本地 marked 与打包 KaTeX，实际解析了两份正文所有公式并生成自包含 HTML/MathML；空文档、行内式、蓝色块内公式、普通引用、单个红色待证及非法命令拒绝的自测见 `preview-render-validation.json`。
- 两份 HTML 均在生成时检查只有一个 danger 原待证位置。已解析不等于已目视验证网页布局。
- 浏览器截图没有成功：初次默认临时目录不存在；更换可写临时目录后，Playwright 自带浏览器缺失；使用系统 Chromium 又因 socket() 权限限制启动失败。没有成功的浏览器布局或颜色继承实测。
- 后备 Matplotlib 排版尝试因不支持标准 LaTeX 命令 lvert 失败，未生成或看过代表式图片；保留标准正文公式，没有为适配该工具改写笔记。
- 按任务范围停止继续渲染尝试。HTML 可读件已生成，但整份 HTML 的实际浏览器显示仍未检查，不宣称代表性显示检查已通过。
