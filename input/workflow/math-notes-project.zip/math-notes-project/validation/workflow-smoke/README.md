# 初读与对照测试输出

本目录完成作者初读、原图与旧稿内容对照、两层正文、来源映射及差异记录；没有执行最终三轮复核，也不代表项目全流程完成。

## 主要文件

- `source-transcript.md`：原稿页序的保真转写。
- `study-notes.md`：保留 A/B、原旁注、重复、待证及旧稿补充的学习稿。
- `differences.md`：原图/旧稿差异及首次测试发现、修订。
- `source-old-map.json`、`source-old-map.md`：双向映射；`old-inventory.md` 为旧稿逐项清单。
- `initial-read-inventory.md`、`initial-region-coverage.md`、`blind-read-seal.json`：打开旧稿内容之前保存的原图初读记录。
- `render/`：原 PDF 副本、全页、六区和实际查看的额外横向裁图。
- `math-validation.md`、`math-validation.json`：数学证明、适用条件和 Python 核验输入输出。
- `source-transcript.html`、`study-notes.html`：由本地 KaTeX 解析生成的 HTML/MathML 可读件；实际浏览器布局仍未验证。
- `status.json`、`structural-check.json`：本轮边界及有限结构检查，不是完整项目审计。

## 保留的限制

另一位新审阅者的全部页区第二遍核查、最终冻结后的连续三轮全量独立复核及最终项目审计均未开展。浏览器启动受限；后备数学排版工具也未成功生成代表式图片，因此不宣称已经通过实际网页或代表性图像显示检查。详见 `preview/browser-render-validation.json`。

原稿未明示取值范围只作为补充公式的适用条件说明；未新增字迹疑点或用户待确认任务。物理空白页普通记账，待证后的自然空间不重复制造红色任务。

盲读日志个别英文用词澄清见 `visual-read-log-clarification.md`；已封存文件未回改。
