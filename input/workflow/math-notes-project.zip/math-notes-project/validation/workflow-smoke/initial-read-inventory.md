# 原图初读清单（盲读保存）

本清单形成时尚未打开 `old.md` 内容。原图：`render/source.pdf`；页图、六区图路径见 `render/manifest.json`。本次均为作者 `/root/forward_test` 的初读，不是独立复核轮。

## 逐页内容

| 来源 ID | 物理页 | 内容 / 对象 | 类型 |
| --- | --- | --- | --- |
| FT-P001-U001 | 1 | 课堂测试：正部与负部 | title |
| FT-P001-U002 | 1 | f+(x)=max(f(x),0) | definition |
| FT-P001-U003 | 1 | f-(x)=min(f(x),0) | definition |
| FT-P001-U004 | 1 | A：证明 f=f+ + f- | problem-A |
| FT-P001-U005 | 1 | 若 f(x)>=0 | condition-A |
| FT-P001-U006 | 1 | f+=f | proof-A |
| FT-P001-U007 | 1 | f-=0 | proof-A |
| FT-P001-U008 | 1 | 故等式成立 | proof-A |
| FT-P001-U009 | 1 | 若 f(x)<0 | condition-A |
| FT-P001-U010 | 1 | f+=0 | proof-A |
| FT-P001-U011 | 1 | f-=f | proof-A |
| FT-P001-U012 | 1 | 故等式成立 | proof-A |
| FT-P001-U013 | 1 | B：证明 \|f\|=f+ - f- | problem-B |
| FT-P001-U014 | 1 | 若 f(x)>=0 | condition-B |
| FT-P001-U015 | 1 | 右边为 f(x)=\|f(x)\| | proof-B |
| FT-P001-U016 | 1 | 若 f(x)<0 | condition-B |
| FT-P001-U017 | 1 | 右边为 -f(x)=\|f(x)\| | proof-B |
| FT-P001-U018 | 1 | 边界：f(x)=0 时 | boundary |
| FT-P001-U019 | 1 | 两个部分都等于0 | boundary |
| FT-P001-U020 | 1 | 旁注：老师的负部取非正值，不改符号约定 | side-note |
| FT-P001-U021 | 1 | 再记一次：f=f+ + f-。（有意重复） | intentional-repeat |
| FT-P001-U022 | 1 | 待证：此构造保持可测性 | original-pending |
| FT-P001-U023 | 1 | 原稿在待证后未写证明；到下一箭头行前保留空位 | original-answer-space |
| FT-P001-U024 | 1 | 跨行箭头：定义 → 分情况 → 恒等式 | arrow-nodes |
| FT-P001-U025 | 1 | 定义 → 分情况：从定义进入分情况讨论 | arrow-edge |
| FT-P001-U026 | 1 | 分情况 → 恒等式：分情况得到恒等式 | arrow-edge |
| FT-P002-U001 | 2 | 物理第2页：未见文字、公式、图形或笔迹，保留整页空白记录 | blank-page |

## 视觉检查与连续性

- 第1页先全页辨认阅读顺序，再逐一打开六区图；之后回到全页核对横跨左右区的定义、A/B证明行、有意重复和箭头。
- 第2页先看全页，再逐一看六区（含页边和中央），最后再次回全页；未见文字、公式、浅色痕迹或图。整页空白作为来源对象保留，不将自动候选当结论。
- 第1页底部箭头与上方定义、分情况、恒等式的关系均保留；可测性待证后没有现成证明。
- 未看到划去文字或另一个独立反例；不能据此排除后续独立审阅发现的遗漏。

## 限制

- 原稿为清晰排印测试页；本轮无无法唯一恢复的字形。
- 目前仅完成初读，未执行第二位独立审阅者复核或最终连续三轮复核。
- 本轮开始时 coordinator-prompt.md、worker-prompt.md、references/tools.md、自测脚本尚未存在；使用实际脚本 help 确认渲染参数。
