# 双向来源映射

## 原图 → 两份正文

| 原图 ID | 转写稿锚点 | 学习稿锚点 | 对应旧稿 |
| --- | --- | --- | --- |
| FT-P001-U001 | ft-p001-u001 | sn-000 | OT-U001 |
| FT-P001-U002 | ft-p001-u002 | sn-001 | — |
| FT-P001-U003 | ft-p001-u003 | sn-001 | OT-U002 |
| FT-P001-U004 | ft-p001-u004 | sn-002 | OT-U003 |
| FT-P001-U005 | ft-p001-u005 | sn-003 | OT-U004 |
| FT-P001-U006 | ft-p001-u006 | sn-003 | — |
| FT-P001-U007 | ft-p001-u007 | sn-003 | — |
| FT-P001-U008 | ft-p001-u008 | sn-003 | — |
| FT-P001-U009 | ft-p001-u009 | sn-004 | OT-U005 |
| FT-P001-U010 | ft-p001-u010 | sn-004 | — |
| FT-P001-U011 | ft-p001-u011 | sn-004 | — |
| FT-P001-U012 | ft-p001-u012 | sn-004 | — |
| FT-P001-U013 | ft-p001-u013 | sn-005 | — |
| FT-P001-U014 | ft-p001-u014 | sn-006 | — |
| FT-P001-U015 | ft-p001-u015 | sn-006 | — |
| FT-P001-U016 | ft-p001-u016 | sn-007 | — |
| FT-P001-U017 | ft-p001-u017 | sn-007 | — |
| FT-P001-U018 | ft-p001-u018 | sn-008 | — |
| FT-P001-U019 | ft-p001-u019 | sn-008 | — |
| FT-P001-U020 | ft-p001-u020 | sn-009 | — |
| FT-P001-U021 | ft-p001-u021 | sn-010 | — |
| FT-P001-U022 | ft-p001-u022 | sn-011 | OT-U007 |
| FT-P001-U023 | ft-p001-u023 | sn-011 | — |
| FT-P001-U024 | ft-p001-u024 | sn-013 | — |
| FT-P001-U025 | ft-p001-u025 | sn-014 | — |
| FT-P001-U026 | ft-p001-u026 | sn-015 | — |
| FT-P002-U001 | ft-p002-u001 | sn-018 | — |

## 学习稿 → 来源

| 学习稿锚点 | 原图 ID | 旧稿 ID | 类别 |
| --- | --- | --- | --- |
| sn-000 | FT-P001-U001 | OT-U001 | source-content |
| sn-001 | FT-P001-U002、FT-P001-U003 | OT-U002 | source-content |
| sn-002 | FT-P001-U004 | OT-U003 | source-content |
| sn-003 | FT-P001-U005、FT-P001-U006、FT-P001-U007、FT-P001-U008 | OT-U004 | source-content |
| sn-004 | FT-P001-U009、FT-P001-U010、FT-P001-U011、FT-P001-U012 | OT-U005 | source-content |
| sn-005 | FT-P001-U013 | — | source-content |
| sn-006 | FT-P001-U014、FT-P001-U015 | — | source-content |
| sn-007 | FT-P001-U016、FT-P001-U017 | — | source-content |
| sn-008 | FT-P001-U018、FT-P001-U019 | — | source-content |
| sn-009 | FT-P001-U020 | — | source-content |
| sn-010 | FT-P001-U021 | — | source-content |
| sn-011 | FT-P001-U022、FT-P001-U023 | OT-U007 | original-pending |
| sn-012 | FT-P001-U022 | — | model-supplement |
| sn-013 | FT-P001-U024 | — | source-content |
| sn-014 | FT-P001-U025 | — | source-content |
| sn-015 | FT-P001-U026 | — | source-content |
| sn-016 | — | OT-U006 | old-supplement |
| sn-017 | — | OT-U006 | model-supplement |
| sn-018 | FT-P002-U001 | — | neutral-physical-blank-record |

旧稿逐条去向及原文见 `old-inventory.md`。模型补充不写入原稿转写。空白物理页和普通纸面空位只普通记账；同一可测性待证保留一个红色位置。
