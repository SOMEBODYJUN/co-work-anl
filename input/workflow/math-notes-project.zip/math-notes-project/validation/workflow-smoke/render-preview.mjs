import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';

const bundleRoot = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES;
if (!bundleRoot) throw new Error('CODEX_PRIMARY_RUNTIME_NODE_MODULES is unavailable.');
const {marked} = await import(pathToFileURL(path.join(bundleRoot, 'marked/lib/marked.esm.js')));
const katex = (await import(pathToFileURL(path.join(bundleRoot, '@oai/artifact-tool/dist/chunks/katex-GNQQ5S6U.mjs')))).default;
const outRoot = path.dirname(new URL(import.meta.url).pathname);
const css = [
  'html{background:#f4f6f9;color:#18212c;font-family:"Noto Sans CJK SC","Noto Serif CJK SC",sans-serif;line-height:1.75}',
  'body{max-width:1050px;margin:36px auto;padding:40px 60px;background:#fff}',
  'h1,h2,h3{line-height:1.4}h1{font-size:29px}h2{font-size:24px;border-bottom:1px solid #d3d9e2;padding-bottom:8px}',
  'p,li{font-size:17px}a{color:#275b95}code{background:#f0f2f5;padding:2px 5px;font-size:14px}',
  'blockquote{border-left:4px solid #c6cdd6;padding:12px 22px;margin:18px 0;background:#f6f8fa}',
  'blockquote.info{color:#14539b;background:#eef5ff;border-color:#3c79bd}',
  'blockquote.danger{color:#b32632;background:#fff1f2;border-color:#c54651}',
  'blockquote p{margin:8px 0}.display-math{display:block;overflow-x:auto;margin:16px 0}',
  'math{font-size:1.1em;color:inherit}math[display="block"]{margin:14px 0}',
  'table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccd3dd;padding:8px;text-align:left}'
].join('\n');

function renderMarkdown(markdown) {
  const math = [];
  let input = markdown.replace(/\$\$([\s\S]*?)\$\$/g, (_, content) => {
    const tex = content.replace(/^>\s?/gm, '').trim();
    const html = katex.renderToString(tex, {displayMode:true, output:'mathml', throwOnError:true, strict:'error'});
    const token = 'MATHBLOCKPLACEHOLDER' + math.length + 'TOKEN';
    math.push({token, html:'<span class="display-math">' + html + '</span>'});
    return token;
  });
  input = input.replace(/\$([^$\n]+)\$/g, (_, tex) => {
    const html = katex.renderToString(tex, {displayMode:false, output:'mathml', throwOnError:true, strict:'error'});
    const token = 'MATHINLINEPLACEHOLDER' + math.length + 'TOKEN';
    math.push({token,html});
    return token;
  });
  let html = marked.parse(input);
  for (const item of math) html = html.replaceAll(item.token,item.html);
  html = html.replace(/<blockquote>([\s\S]*?)<\/blockquote>/g, (_, content) => {
    const match = content.match(/\[!(info|danger)\]/);
    return '<blockquote' + (match ? ' class="' + match[1] + '"' : '') + '>' +
      content.replace(/\[!(info|danger)\]\s?/, '') + '</blockquote>';
  });
  return {html, mathCount:math.length};
}

const tests = [];
for (const [name,md,check] of [
  ['empty','',r=>r.mathCount===0],
  ['inline','$f^-(x)=\\min(f(x),0)$',r=>r.mathCount===1 && r.html.includes('<math')],
  ['block-in-callout','> [!info] 补充\n> $$\n> \\frac{f+\\lvert f\\rvert}{2}\n> $$\n',r=>r.mathCount===1 && r.html.includes('class="info"')],
  ['ordinary-quote','> 仅普通引用',r=>r.html.includes('<blockquote>') && !r.html.includes('class="danger"')],
  ['one-original-pending','> [!danger] 原待证\n> 此构造保持可测性。',r=>(r.html.match(/class="danger"/g)||[]).length===1]
]) {
  assert(check(renderMarkdown(md)),name);
  tests.push({name,status:'passed'});
}
assert.throws(()=>renderMarkdown('$$\\notARealCommand{x}$$'));
tests.push({name:'invalid-tex-rejected',status:'passed'});

const rendered = [];
for (const name of ['source-transcript','study-notes']) {
  const md = await fs.readFile(path.join(outRoot,name+'.md'),'utf8');
  const result = renderMarkdown(md);
  assert(!result.html.includes('MATHBLOCKPLACEHOLDER'));
  assert(!result.html.includes('MATHINLINEPLACEHOLDER'));
  assert.equal((result.html.match(/class="danger"/g)||[]).length,1,'Only one red pending position in each note');
  const doc = '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>'+name+
    '</title><style>'+css+'</style></head><body>'+result.html+'</body></html>';
  await fs.writeFile(path.join(outRoot,name+'.html'),doc);
  rendered.push({file:name+'.html',mathCount:result.mathCount});
}
await fs.writeFile(path.join(outRoot,'preview-render-validation.json'),JSON.stringify({
  engine:'marked plus bundled KaTeX, output MathML; browser native MathML',
  tests,rendered,
  limit:'Companion HTML checked here; not a guarantee about every Markdown renderer.'
},null,2)+'\n');
console.log(JSON.stringify({tests,rendered}));
