# 因子二证书的 53 条活跃非负行：节点、比较与来源

本页配套冻结证书 `certificate.json`，其 SHA-256 为：

```text
395e056b218d237abe8b85db894f0b1c37d2e14d55c74b1dca723abeceb6a44e
```

证书的公共分母为 $10^{22}$，目标分子为 $2\cdot10^{22}$。每条行的正整数乘子见该 JSON；共同最大主题变量 $K$ 的逐行系数见 `active_k_columns.json`。本页说明每条行的合法来源，不把任何离轨续局的总收益直接作为实际福利付款。

## 1. 同一完整策略产生的主题与索引

固定原实例、同一份完整纯 SPE $\sigma$，以及一个达到 $O=\mathrm{OPT}_5$ 的五元组 $(T_1,\ldots,T_5)$。所有索引均保留，即使相同主题被重复列出。下述每个回复均由同一 $\sigma$ 在所写的**有序历史**给出。

为避免与社会福利 $W$ 混淆，固定主题标签 `W` 在本页公式中写成 $W_0$。程序与证书中的字符 `W` 及行名保持原样。

| 路径标签 | 五位主题 | 哪些行动是特意强制的 |
|---|---|---|
| `actual` | $(A,B,C,D,E)$ | 无。 |
| `second` | $(A,E,U,V,W_0)$ | 在历史 $(A)$ 强制第二位选 $E$。 |
| `third` | $(A,B,E,X,Y)$ | 在历史 $(A,B)$ 强制第三位选 $E$。 |

因此，`second` 路径上第三至第五位是真正优化者；`third` 路径上第四、第五位是真正优化者。不要求被强制的第二或第三位在该支路上最优。

另外保留下列三个五索引回复族。每一族的不同 $i$ 对应互斥但真实的离轨历史。

| 族 | 第 $i$ 条真续局 | 族内标签及次序 |
|---|---|---|
| `AB` | $(A,B,T_i,X_i^{AB},Y_i^{AB})$ | $Q^{AB}_{i,0}=T_i$，$Q^{AB}_{i,1}=X_i^{AB}$，$Q^{AB}_{i,2}=Y_i^{AB}$。 |
| `AE` | $(A,E,T_i,X_i^{AE},Y_i^{AE})$ | $Q^{AE}_{i,0}=T_i$，$Q^{AE}_{i,1}=X_i^{AE}$，$Q^{AE}_{i,2}=Y_i^{AE}$。 |
| `Sbranch` | $(A,T_i,U_i^S,V_i^S,W_i^S)$ | $Q^S_{i,0}=T_i$，$Q^S_{i,1}=U_i^S$，$Q^S_{i,2}=V_i^S$，$Q^S_{i,3}=W_i^S$。 |

`AB`、`AE` 的第四、第五位，以及 `Sbranch` 的第三至第五位，是真正优化者。

对三条固定路径 $\pi$，另令 $L_i^\pi$ 是该路径前三位历史之后，第四位强制选 $T_i$ 时的真实第五位回复。记 $\mathbf 1_H(x)$ 为客户 $x$ 属于主题 $H$ 的会员位。对每个客户定义

$$
d(x)=\sum_{i=1}^5\mathbf 1_{T_i}(x),\qquad
\ell_\pi(x)=\sum_{i=1}^5\mathbf 1_{L_i^\pi}(x),\qquad
h_\pi(x)=\sum_{i=1}^5\mathbf 1_{T_i}(x)\mathbf 1_{L_i^\pi}(x).
$$

三套 $L$ 菜单各自存在于同一原策略中。以下在逐客户公式中省略 $d,\ell_\pi,h_\pi$ 的自变量 $x$。

以下 $v_j^\pi$ 是固定路径 $\pi$ 上第 $j$ 位的真实终局收益，$v_{i,j}^F$ 是索引族 $F$ 第 $i$ 路上的第 $j$ 位收益。实际路径收益记为 $u_j=v_j^{\mathrm{actual}}$。客户前缀负载一律按所写路径计算，不把别条路径的前缀或尾部代入。

固定标签次序为 `ABCDEUVWXY`，对应数字 $0$ 至 $9$；其数学主题依次是 $(A,B,C,D,E,U,V,W_0,X,Y)$。

## 2. 基本合法行的统一定义

### 2.1 真节点对目录主题的比较

在某条真路径的真正第 $j$ 位节点，客户前缀负载为 $p_j(x)$。该玩家偏离任一合法主题 $H$ 后，对 $x\in H$ 的最终负载至多为 $p_j(x)+6-j$。因此

$$
v_j-\sum_{x\in H}\frac{1}{p_j(x)+6-j}\ge0.
\tag{IC-floor}
$$

第五位时，这就是精确最佳回复不等式，未估计或冻结任何未来行动。对若干合法主题求和得到相应的 `sum` 行。菜单主题在其他历史是否是最优者，与它在当前节点是否是合法可比较行动，是不同问题；这些行只需要后者。

`*:5:O` 的覆盖行是

$$
5v_5+\sum_x\frac{p_5(x)}{p_5(x)+1}-\mathrm{OPT}_5\ge0.
\tag{O-floor}
$$

它由第五位依次比较 $T_i$ 并求和，以及逐客户不等式

$$
\frac{d}{p+1}+\frac{p}{p+1}\ge\mathbf 1_{\{d>0\}}
$$

得到。此处收益、前缀和五次比较属于同一末节点。

### 2.2 固定前缀的真实末回复菜单

对固定路径 $\pi$，令 $p(x)$ 是前三位负载，$b(x)$ 是其第四位主题会员位，并令

$$
\Delta(x)=(p(x)+1)(p(x)+2).
$$

下列行对该路径成立：

$$
\begin{aligned}
S_\pi
&=5v_4^\pi-\sum_x\left(\frac{d}{p+1}-\frac{h_\pi}{\Delta}\right),\\
V_\pi
&=\sum_x\frac{d\ell_\pi-5h_\pi}{\Delta},\\
Z_\pi
&=5v_5^\pi-\sum_x\frac{\ell_\pi}{p+b+1},\\
C_{\pi,\rho}
&=\sum_x\left(
\frac{5(\ell_\pi-\ell_\rho)}{p+1}
+\frac{d\ell_\rho-5h_\pi}{\Delta}
\right).
\end{aligned}
$$

四者均非负。$S_\pi$ 是第四位五次强制 $T_i$ 的真实偏离 IC；$V_\pi$ 是五个真末节点各自对五个同菜单 $L_j^\pi$ 的最佳回复不等式之和；$Z_\pi$ 是原第五位对五个 $L_i^\pi$ 的最佳回复不等式之和；$C_{\pi,\rho}$ 是前一套五个末节点各自对后一套五个合法菜单主题的最佳回复不等式之和。不同菜单只作为合法查询进入，未将各分支收益免费加到实际福利。

### 2.3 保留一个重叠项的末两人行

任意真正末两人节点，背景负载为 $p(x)$，真实第四、第五位主题为 $B_*,C_*$。定义

$$
\begin{aligned}
H&=v_4+v_5+\sum_{x\in B_*}\frac{1}{(p(x)+1)(p(x)+2)},\\
f(L)&=\sum_{x\in L}\frac{1}{p(x)+1},\\
g(L,M)&=\sum_{x\in L\cap M}\frac{1}{(p(x)+1)(p(x)+2)}.
\end{aligned}
$$

对任意两个合法主题 $L,M$，有

$$
H-f(L)-f(M)+g(L,M)\ge0.
\tag{PAIR}
$$

其自足证明只用三条真 IC：第四位偏离 $L$，其真末回复记为 $R$；该回复 $R$ 比较 $M$；原真末位 $C_*$ 比较 $R$。三式相加并使用

$$
g(B_*,R)\le\sum_{x\in B_*}\frac{1}{(p(x)+1)(p(x)+2)},
$$

即得 (PAIR)。这说明 `overlap=1` 的系数是可信的；不用较弱的仅剩余利润税行替代。

对族 $F$ 的末两人节点逐 $i$ 应用 (PAIR)，取

$$
(L,M)=(Q^F_{j,r},Q^F_{j,s}),
$$

并对所有 $i\ne j$ 求和，得到 `F:pair:rs:query_equal`。它包含 $20$ 条合法比较。

## 3. 全部 35 条活跃原始节点行（含最终修补行）

以下简写 `last(π)` 表示相应固定路径真第五位；“最佳回复之和”均为所列全部索引求和。

| 行名 | 精确语义 |
|---|---|
| `actual:5:K:U` | `last(actual)` 比较固定主题 $U$。 |
| `actual:5:K:Y` | `last(actual)` 比较固定主题 $Y$。 |
| `actual:5:O` | actual 的 (O-floor)。 |
| `actual:reply:S` | $S_{\mathrm{actual}}$。 |
| `actual:reply:V` | $V_{\mathrm{actual}}$。 |
| `actual:reply:Z` | $Z_{\mathrm{actual}}$。 |
| `second:5:K:D` | `last(second)` 比较固定主题 $D$。 |
| `second:5:O` | second 的 (O-floor)。 |
| `second:reply:S` | $S_{\mathrm{second}}$。 |
| `second:reply:V` | $V_{\mathrm{second}}$。 |
| `second:reply:Z` | $Z_{\mathrm{second}}$。 |
| `third:reply:V` | $V_{\mathrm{third}}$。 |
| `third:reply:cross-L-actual` | $C_{\mathrm{third},\mathrm{actual}}$。 |
| `second:5:sum-L-third` | `last(second)` 比较五个 $L_i^{\mathrm{third}}$ 的最佳回复之和。 |
| `F:second` | $u_2-v_2^{\mathrm{second}}\ge0$；actual 第二位在 $(A)$ 偏离 $E$。 |
| `F:third` | $u_3-v_3^{\mathrm{third}}\ge0$；actual 第三位在 $(A,B)$ 偏离 $E$。 |
| `AB:F3` | $5u_3-\sum_i v_{i,3}^{AB}\ge0$；actual 第三位分别偏离五个 $T_i$。 |
| `AB:5:sum-Y` | AB 族五个真末节点各自比较全部五个 $Y_j^{AB}$，共 $25$ 条最佳回复不等式。 |
| `AB:actual:5:sum-X` | `last(actual)` 比较五个 $X_i^{AB}$ 的最佳回复之和。 |
| `AE:F3` | $5v_3^{\mathrm{second}}-\sum_i v_{i,3}^{AE}\ge0$；$(A,E)$ 的真第三位分别偏离五个 $T_i$。 |
| `AE:5:K:D` | AE 族五个真末节点分别比较固定主题 $D$。 |
| `AE:5:sum-Y` | AE 族五个真末节点各自比较全部五个 $Y_j^{AE}$，共 $25$ 条最佳回复不等式。 |
| `AE:actual:5:sum-X` | `last(actual)` 比较五个 $X_i^{AE}$。 |
| `AE:second:5:sum-X` | `last(second)` 比较五个 $X_i^{AE}$。 |
| `AE:second:5:sum-Y` | `last(second)` 比较五个 $Y_i^{AE}$。 |
| `Sbranch:F2` | $5u_2-\sum_i v_{i,2}^{S}\ge0$；actual 第二位分别偏离五个 $T_i$。 |
| `Sbranch:5:sum-W` | S 族五个真末节点各自比较全部五个 $W_j^S$，共 $25$ 条最佳回复不等式。 |
| `actual:5:sum-SU` | `last(actual)` 比较五个 $U_i^S$。 |
| `AB:5:offdiag:0` | AB 族第 $i$ 个真末节点比较 $T_j$，对全部 $i\ne j$ 求和。 |
| `AE:5:offdiag:0` | AE 族第 $i$ 个真末节点比较 $T_j$，对全部 $i\ne j$ 求和。 |
| `Sbranch:5:offdiag:1` | S 族第 $i$ 个真末节点比较 $U_j^S$，对全部 $i\ne j$ 求和。 |
| `AB:pair:12:query_equal` | AB 族的 (PAIR) 求和；两个查询是同索引 $X_j^{AB},Y_j^{AB}$，且 $i\ne j$。 |
| `AE:pair:12:query_equal` | AE 族的 (PAIR) 求和；查询为 $X_j^{AE},Y_j^{AE}$，且 $i\ne j$。 |
| `Sbranch:pair:23:query_equal` | S 族的 (PAIR) 求和；查询为 $V_j^S,W_j^S$，且 $i\ne j$。 |
| `actual:5:sum-SV` | 最终精确修补行：`last(actual)` 比较五个 $V_i^S$；乘子为 $1/10000$。 |

上表列出 **35** 行，即 $34$ 条原活跃节点行加 $1$ 条修补行。所有求和保留原始终局中的客户单位价值和玩家单位权。

## 4. 18 条活跃容量与投影行

所有局部投影都对**任意合法主题对** $(T,Q)$ 成立，所以可把真实目录菜单按固定标签或同索引代入。令 $M=10^6$。局部证明给出收益、$K$ 系数及逐客户 $\gamma$ 表时，将左侧系数向上取整到 $1/M$ 的整数倍，右侧 $\gamma$ 向下取整到 $1/M$ 的整数倍，再整体乘 $M$。收益和 $K$ 均非负，因此这只减弱不等式。$\gamma$ 可以为负；向下取整的方向仍然正确。

### 4.1 基本来源映射

以下“第 $r$ 项”均指 JSON 数组的**从零开始的索引**。`BG`、`PC` 是证书中的投影编号；它们不一定等于对应源文件的数组索引。

| 证书投影编号 | 便携局部来源 | 源文件数组索引 |
|---|---|---|
| `DEEP:0` | `components/deep_root_query.json` | $0$ |
| `BG:0` | `components/background_player2.json` | $0$ |
| `BG:2` | `components/background_player2.json` | $3$ |
| `BG:4` | `components/background_player2.json` | $11$ |
| `PC:0`、`PC:1`、`PC:2`、`PC:3` | `components/priced_player2.json` | 分别为 $0,1,2,3$ |
| `PC:5`、`PC:6`、`PC:7` | `components/priced_player3.json` | 分别为 $0,1,2$ |
| `MAXROOT-NEW` | `components/maxroot_four_copy.json` | $0$ |

完整 `BG` 表的前六项按 `components/background_player2.json` 的索引 $[0,1,3,5,11,12]$ 排列，其后三项来自 `components/background_player3.json` 的索引 $[0,1,2]$。完整 `PC` 表按 `components/priced_player2.json` 的索引 $[0,1,2,3,4]$，随后按 `components/priced_player3.json` 的索引 $[0,1,2]$ 排列。此顺序在便携核验器中显式固定，不依赖发现阶段的浮点元数据或重新排序。

`DEEP:0` 的原始任意根主题／查询主题不等式为

$$
\lvert Q\setminus T\rvert
\le\alpha u_1+\beta K+\gamma\lvert T\rvert
+\zeta\lvert Q\cap T\rvert.
$$

令 $t=\mathbf 1_T(x)$、$q=\mathbf 1_Q(x)$，令 $u_{1,x}$ 为实际第一位从客户 $x$ 得到的收益。向外取整后的逐客户行是

$$
11756189\,u_{1,x}
-4549756\,t
-1000000\,q
+684765\,tq,
$$

且 $K$ 系数为 $2514500$。

活跃的 `BG:0`、`BG:2`、`BG:4` 均为

$$
u_2+b_KK\ge\sum_x\gamma[4a+2t+q],
$$

其中背景是固定实际第一主题 $A$，$a=\mathbf 1_A(x)$；$b_K$ 表示该局部不等式的 $K$ 系数。

`PC:0`、`PC:1`、`PC:2`、`PC:3` 的形式为

$$
u_2+\sum_{j=1}^5\alpha_j u_j+b_KK
\ge\sum_x\gamma[32a+16b+8c+4\delta+2t+q].
$$

此处 $a,b,c,\delta$ 分别是客户对实际主题 $A,B,C,D$ 的会员位，特别地 $\delta=\mathbf 1_D(x)$ 与最优重数 $d$ 不同。源文件 `u_coefs` 存储的是 $\alpha_j$，所以左侧还包括显式的 $u_2$。

`PC:5`、`PC:6`、`PC:7` 的左侧为 `components/priced_player3.json` 中 `u_coefficients` 给出的**完整**实际收益系数，以及该项的 $K$ 系数；无需另加一次 $u_2$。它们使用相同的 $64$ 项会员位编码。

`MAXROOT-NEW` 经向外取整后为

$$
46313177u_1-7412362K-1000000\mathrm{OPT}_5\ge0.
$$

写成正容量扣减常数时，其原始精确常数为

$$
B=\frac{94866177440}{2048362573},\qquad
C=\frac{60732827017}{8193450292},\qquad
\mathrm{OPT}_5\le Bu_1-CK.
$$

源 JSON 的字段 `C` 使用带符号写法，即存储上述 $-C$。两种写法表示同一不等式。

这些源文件索引与完整取整结果由 `row_manifest.json` 冻结，不能靠后来改变的排序或文件内容重新猜测。局部证明的节点说明与精确验证另见 `LOCAL_LEMMAS_ZH.md`、`MAXROOT_LEMMA_ZH.md` 及 `components/verify_local_components.py`。

### 4.2 逐条代入表

| 行名 | 任意主题对投影中的代入／直接含义 |
|---|---|
| `MAX:fixed:2` | $K-\lvert C\rvert\ge0$。 |
| `DEEP:0:5:3` | DEEP 第 $0$ 投影，$T=U$、$Q=D$。 |
| `BG:0:6:7` | BG 第 $0$ 投影，$T=V$、$Q=W_0$。 |
| `BG:0:7:6` | BG 第 $0$ 投影，$T=W_0$、$Q=V$。 |
| `BG:2:3:4` | BG 第 $2$ 投影，$T=D$、$Q=E$。 |
| `BG:4:5:3` | BG 第 $4$ 投影，$T=U$、$Q=D$。 |
| `MAXROOT-NEW` | 上述实际 $u_1$、共同 $K$ 和 $\mathrm{OPT}_5$ 的最大根容量行。 |
| `AE:BG:0:eq:2:1` | BG 第 $0$ 投影对 $T=Y_i^{AE}$、$Q=X_i^{AE}$ 按 $i=1,\ldots,5$ 求和。 |
| `Sbranch:BG:0:eq:2:3` | BG 第 $0$ 投影对 $T=V_i^S$、$Q=W_i^S$ 按 $i$ 求和。 |
| `PC:0:6:7` | PC 第 $0$ 投影，$T=V$、$Q=W_0$。 |
| `PC:2:7:6` | PC 第 $2$ 投影，$T=W_0$、$Q=V$。 |
| `PC:3:7:6` | PC 第 $3$ 投影，$T=W_0$、$Q=V$。 |
| `AB:PC:5:eq:2:1` | PC 第 $5$ 投影对 $T=Y_i^{AB}$、$Q=X_i^{AB}$ 按 $i$ 求和。 |
| `AB:PC:6:eq:1:2` | PC 第 $6$ 投影对 $T=X_i^{AB}$、$Q=Y_i^{AB}$ 按 $i$ 求和。 |
| `AB:PC:6:eq:2:1` | PC 第 $6$ 投影对 $T=Y_i^{AB}$、$Q=X_i^{AB}$ 按 $i$ 求和。 |
| `AE:PC:6:eq:2:1` | PC 第 $6$ 投影对 $T=Y_i^{AE}$、$Q=X_i^{AE}$ 按 $i$ 求和。 |
| `Sbranch:PC:1:eq:3:2` | PC 第 $1$ 投影对 $T=W_i^S$、$Q=V_i^S$ 按 $i$ 求和。 |
| `Sbranch:PC:7:eq:3:2` | PC 第 $7$ 投影对 $T=W_i^S$、$Q=V_i^S$ 按 $i$ 求和。 |

每个 `eq` 行都是同一个局部不等式的五次合法代入相加，其常数收益和 $K$ 系数因此乘 $5$。没有将不同索引下的收益或背景悄悄识别；左侧是局部定理已经投影成的同一组**实际**收益与同一个 $K$。

## 5. 完整类型域和符号

每个真实客户被送入：$10$ 个固定会员位、最优重数 $d\in\{0,\ldots,5\}$、三组索引族直方图（分别为 $5$ 个三位、三位、四位会员类型的直方图），以及三套 $(\ell,h)$。所有真实客户都在该域内；未强加历史匿名性。事实上，允许域可能严格大于可实现域，因此只会加强需要核验的非负性要求。

给定固定会员位和共享 $d$，三族直方图的活跃项分离。每族只需在自己的全部 $792$、$792$、$15504$ 个直方图中，筛选第一会员位重数等于该共享 $d$ 的项后取极值。每套 $(\ell,h)$ 满足

$$
0\le h\le d,\qquad 0\le\ell-h\le5-d.
$$

其所有活跃项均为仿射，故四个角点

$$
(0,0),\quad(d,d),\quad(5-d,0),\quad(5,d)
$$

完整覆盖极值。独立实现重建 $6144$ 个条件态并作精确整数比较。

若每条行为

$$
G_q=\sum_x g_q(x)+k_qK\ge0,
$$

证书给出

$$
2W-\mathrm{OPT}_5
=\sum_q\frac{L_q}{10^{22}}G_q
+\sum_x\rho(x)
+\frac{2264870}{10^{22}}K,
\qquad \rho(x)\ge0.
$$

这里

$$
-\sum_qL_qk_q=2264870>0.
$$

$K$ 是全目录同一个最大主题大小，不是每条行分别选择的容量。双方独立全类型审计均返回精确最小余项 $0$；没有浮点容忍、规模截断、可实现性假设或删除平局。空主题的会员位为零，重复主题的索引仍保留；零客户时逐客户和为空，上述恒等式仍成立。
